#!/usr/bin/env node

const { run } = require("./binary");
run("gemini-image-mcp");
